data:extend(
{
  {
    type = "autoplace-control",
    name = "iron-ore",
    richness = true,
    order = "b-a"
  },
  {
    type = "autoplace-control",
    name = "copper-ore",
    richness = true,
    order = "b-b"
  },
  {
    type = "autoplace-control",
    name = "stone",
    richness = true,
    order = "b-c"
  },
  {
    type = "autoplace-control",
    name = "coal",
    richness = true,
    order = "b-d"
  },
  {
    type = "autoplace-control",
    name = "crude-oil",
    richness = true,
    order = "b-e"
  },
  {
    type = "autoplace-control",
    name = "enemy-base",
    richness = true,
    order = "d-a"
  },
}
)
